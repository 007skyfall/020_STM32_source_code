#include "sensor.h"
#include "nbiotdriver.h"
#include "time.h"
#include "adc.h"

uint8_t IrStatus = 0;

uint8_t IrValue = 0;


uint16_t AdcValue = 0;

static tsTimeType TimeSensor;




void SensorTask(void)
{

	if(CompareTime(&TimeSensor))
	{
	
		HAL_ADC_Start(&hadc);
		
		HAL_ADC_PollForConversion(&hadc,1);
		
		if(HAL_IS_BIT_SET(HAL_ADC_GetState(&hadc), HAL_ADC_STATE_REG_EOC))
		{
			
			AdcValue = HAL_ADC_GetValue(&hadc);
			printf("AdcValue = %d\r\n",AdcValue);
			
		
		
		
		
		}
		SetTime(&TimeSensor,TIMESEOSOR);
	
	
	
	
	}
}

