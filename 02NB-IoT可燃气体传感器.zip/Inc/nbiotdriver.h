#ifndef _NBIOTDRIVER_H
#define _NBIOTDRIVER_H

#include "stm32f0xx.h"

#define SENDDATATIME 3600*1000
typedef enum
{
	SUCCESS_REC = 0,
	TIME_OUT,
	NO_REC

}teATStatus;

typedef enum
{
	NB_IDIE = 0,
	NB_SEND,
	NB_WAIT,
	NB_ACCESS
}teNB_TaskStatus;
typedef enum
{
	AT_CFUN0 = 0,
	AT_CGSN,
	AT_NRB,
	AT_NCDP,
	AT_CFUN1,
	AT_CIMI,
	AT_CMEE,
	AT_CGDCONT,
	AT_NNMI,
	AT_CGATT,
	AT_CGPADDR,
	AT_NMGS,
	AT_IDIE,

}teATCmdNum;
typedef struct
{
	char *ATSendStr;
	char *ATRecStr;
	uint16_t TimeOut;
	teATStatus ATStatus;
	uint8_t RtyNum;
}tsATCmds;


uint8_t ReadAccessStatus(void);
void TriggerSendData(void);

void NB_Init(void);


void NB_Task(void);

#endif
