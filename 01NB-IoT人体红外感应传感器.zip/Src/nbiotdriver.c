#include "nbiotdriver.h"
#include "usart.h"
#include "time.h"
#include "led.h"
#include "sensor.h"

#include <string.h>
static uint8_t CurrentRty;
static teATCmdNum ATRecCmdNum;
static teATCmdNum ATCurrentCmdNum;
static teATCmdNum ATNextCmdNum;
static teNB_TaskStatus NB_TaskStatus;
static tsTimeType TimeNB;
static tsTimeType TimeNBSendData;
static uint8_t IsAccess;
char NB_SendDataBuff[100];
tsATCmds ATCmds[] = 
{
	{"AT+CFUN=0\r\n","OK",2000,NO_REC,3},
	{"AT+CGSN=1\r\n","OK",2000,NO_REC,3},
	{"AT+NRB\r\n","OK",8000,NO_REC,3},
	{"AT+NCDP=180.101.147.115,5683\r\n","OK",2000,NO_REC,3},
	{"AT+CFUN=1\r\n","OK",2000,NO_REC,3},
	{"AT+CIMI\r\n","OK",2000,NO_REC,3},
	{"AT+CMEE=1\r\n","OK",2000,NO_REC,3},
	{"AT+CGDCONT=1,\"IP\",\"ctnb\"\r\n","OK",2000,NO_REC,3},
	{"AT+NNMI=1\r\n","OK",2000,NO_REC,3},
	{"AT+CGATT=1\r\n","OK",2000,NO_REC,3},
	{"AT+CGPADDR\r\n","+CGPADDR:1,1",2000,NO_REC,30},
	{"AT+NMGS=","OK",3000,NO_REC,3},

};


void ATSend(teATCmdNum ATCmdNum)
{
	//��ս��ջ�����
	memset(Usart2type.Usart2RecBuff,0,USART2_REC_SIZE);
	ATCmds[ATCmdNum].ATStatus = NO_REC;
	
	ATRecCmdNum = ATCmdNum;
	
	if(ATCmdNum == AT_NMGS)
	{
		memset(NB_SendDataBuff,0,100);
		sprintf(NB_SendDataBuff,"%s%d,%02x%02x\r\n",ATCmds[ATCmdNum].ATSendStr,2,0x00,IrValue);
		HAL_UART_Transmit(&huart2,(uint8_t*)NB_SendDataBuff,strlen(NB_SendDataBuff),100);
		HAL_UART_Transmit(&huart1,(uint8_t*)NB_SendDataBuff,strlen(NB_SendDataBuff),100);
	
	}
	else
	{
		HAL_UART_Transmit(&huart2,(uint8_t*)ATCmds[ATCmdNum].ATSendStr,strlen(ATCmds[ATCmdNum].ATSendStr),100);
		HAL_UART_Transmit(&huart1,(uint8_t*)ATCmds[ATCmdNum].ATSendStr,strlen(ATCmds[ATCmdNum].ATSendStr),100);
	}
		//�򿪳�ʱ��ʱ��
	SetTime(&TimeNB,ATCmds[ATCmdNum].TimeOut);
	
	
	
	//�򿪷���ָʾ��
	SetLedRun(LED_TX);
}

void ATRec(void)
{
		if(Usart2type.Usart2RecFlag)
		{
			if(strstr((const char*)Usart2type.Usart2RecBuff,ATCmds[ATRecCmdNum].ATRecStr) != NULL)
			{
				ATCmds[ATRecCmdNum].ATStatus = SUCCESS_REC;

			}
			
			SetLedRun(LED_RX);
			HAL_UART_Transmit(&huart1,Usart2type.Usart2RecBuff,Usart2type.Usart2RecLen,100);
			Usart2type.Usart2RecFlag = 0;
			Usart2type.Usart2RecLen = 0;
		
		
		
		}





}


uint8_t ReadAccessStatus(void)
{

	return IsAccess;
}


void TriggerSendData(void)
{

	ATCurrentCmdNum = AT_NMGS;
	ATNextCmdNum = AT_IDIE;
	SetTime(&TimeNBSendData,SENDDATATIME);
	NB_TaskStatus = NB_SEND;





}


void NB_Init(void)
{

	IsAccess = 0;
	NB_TaskStatus = NB_SEND;
	ATCurrentCmdNum = AT_CFUN0;
	ATNextCmdNum = AT_CGSN;

}


void NB_Task(void)
{

	while(1)
	{
	
		switch(NB_TaskStatus)
		{
			case NB_IDIE:
					 if(CompareTime(&TimeNBSendData))
					 {
							TriggerSendData();
							break;
					 }
				return;
			case NB_SEND:
						if(ATCurrentCmdNum != ATNextCmdNum)
						{
							
						
							CurrentRty = ATCmds[ATCurrentCmdNum].RtyNum;
						
						
						}
						ATSend(ATCurrentCmdNum);
						NB_TaskStatus = NB_WAIT;
				return;
			case NB_WAIT:
					ATRec();
					if(ATCmds[ATCurrentCmdNum].ATStatus == SUCCESS_REC)
					{
						if(ATCurrentCmdNum == AT_CGPADDR)
						{
						
							NB_TaskStatus = NB_ACCESS;
							break;
						
						
						}
						else if(ATCurrentCmdNum == AT_NMGS)
						{
						
							NB_TaskStatus = NB_IDIE;
							break;
						
						
						}
						else
						{
							
							ATCurrentCmdNum += 1;
						
							ATNextCmdNum = ATCurrentCmdNum+1;
							NB_TaskStatus = NB_SEND;
							break;

						}
					
					
					
					
					
					}
					else if(CompareTime(&TimeNB))
					{
						ATCmds[ATCurrentCmdNum].ATStatus = TIME_OUT;
						if(CurrentRty > 0)
						{
							CurrentRty--;
							ATNextCmdNum = ATCurrentCmdNum;
							NB_TaskStatus = NB_SEND;
							break;
						
						
						}
						else
						{
							NB_Init();
							return;
						
						
						
						
						
						}
						
						
					
					
					
					
					
					
					}
				return;
			case NB_ACCESS:
						LedOn(LED_NET);
						IsAccess = 1;
						TriggerSendData();
						break;
			default:
				return;

		}
	
	
	
	
	
	
	}



}


