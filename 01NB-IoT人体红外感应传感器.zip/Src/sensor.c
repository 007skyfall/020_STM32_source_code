#include "sensor.h"
#include "nbiotdriver.h"

uint8_t IrStatus = 0;

uint8_t IrValue = 0;


void SensorTask(void)
{

	if((IrStatus ==1)&&ReadAccessStatus())
	{
	
		IrStatus = 0;
		
		TriggerSendData();
		
		
		printf("IR is Trigger!\r\n");
	
	
	
	
	
	}
	
	IrValue = HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_8);
}

