#ifndef _SENSOR_H
#define _SENSOR_H

#include "stm32f0xx.h"

extern uint8_t IrStatus;

extern uint8_t IrValue;

void SensorTask(void);

#endif
