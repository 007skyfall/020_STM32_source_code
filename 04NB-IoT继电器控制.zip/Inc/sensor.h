#ifndef _SENSOR_H
#define _SENSOR_H

#include "stm32f0xx.h"
#define TIMESEOSOR 10*1000
extern uint8_t IrStatus;

extern uint8_t IrValue;

extern uint16_t AdcValue;
extern uint8_t RelayStatus;
void SensorTask(void);
void RelayOn(void);
void RelayOff(void);

#endif
